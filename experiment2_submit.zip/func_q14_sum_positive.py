def sum_positive(lst):
    return sum(x for x in lst if x > 0)

test_lists = [
    [1, -2, 3, -4, 5],
    [-1, -2, -3],
    [0, 0, 0, 1],
    [10, -20, 30, -40, 50, -60],
]

for lst in test_lists:
    result = sum_positive(lst)
    print(f"列表: {lst}  =>  正数之和: {result}")
