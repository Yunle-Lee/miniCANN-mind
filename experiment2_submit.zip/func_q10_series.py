def sum_n(n):
    return sum(range(1, n + 1))

def sum_n2(n):
    return sum(i ** 2 for i in range(1, n + 1))

def sum_inv(n):
    return sum(1 / i for i in range(1, n + 1))

s = sum_n(100) + sum_n2(50) + sum_inv(10)
print(f"s = ∑_{{k=1}}^{{100}} k + ∑_{{k=1}}^{{50}} k² + ∑_{{k=1}}^{{10}} 1/k")
print(f"∑_{{k=1}}^{{100}} k = {sum_n(100)}")
print(f"∑_{{k=1}}^{{50}} k² = {sum_n2(50)}")
print(f"∑_{{k=1}}^{{10}} 1/k = {sum_inv(10):.6f}")
print(f"\ns = {s:.6f}")
