people = ["甲", "乙", "丙", "丁"]

for doer in people:
    statements = [
        doer != "甲",
        doer == "丙",
        doer == "丁",
        doer != "丁",
    ]
    true_count = sum(statements)
    if true_count == 3:
        print(f"做好事的人是: {doer}")
        print("证词分析:")
        print(f"  甲说'不是我': {statements[0]}")
        print(f"  乙说'是丙': {statements[1]}")
        print(f"  丙说'是丁': {statements[2]}")
        print(f"  丁说'丙说的不对': {statements[3]}")
        print(f"  说真话人数: {true_count}")
