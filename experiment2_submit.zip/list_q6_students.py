students = [
    ["001", "张三", 20],
    ["002", "李四", 19],
    ["003", "王五", 21],
    ["004", "赵六", 18],
    ["005", "孙七", 22],
]

print("初始学生信息:")
for s in students:
    print(f"  学号:{s[0]} 姓名:{s[1]} 年龄:{s[2]}")
print()

students.append(["006", "周八", 20])
print("1. 末尾添加新学生后:")
for s in students:
    print(f"  学号:{s[0]} 姓名:{s[1]} 年龄:{s[2]}")
print()

students.insert(2, ["007", "吴九", 19])
print("2. 在索引2处插入学生后:")
for s in students:
    print(f"  学号:{s[0]} 姓名:{s[1]} 年龄:{s[2]}")
print()

print("3. 学号为003的学生信息:")
for s in students:
    if s[0] == "003":
        print(f"  学号:{s[0]} 姓名:{s[1]} 年龄:{s[2]}")
print()

print("4. 所有学生姓名:")
names = [s[1] for s in students]
print("  ", names)
print()

ages = [s[2] for s in students]
avg_age = sum(ages) / len(ages)
print(f"5. 学生平均年龄: {avg_age:.1f}")
print()

print("6. 年龄大于19的学生信息:")
for s in students:
    if s[2] > 19:
        print(f"  学号:{s[0]} 姓名:{s[1]} 年龄:{s[2]}")
