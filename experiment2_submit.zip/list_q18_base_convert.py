def dec_to_bin(n):
    return bin(n)[2:]

def dec_to_oct(n):
    return oct(n)[2:]

def dec_to_hex(n):
    return hex(n)[2:].upper()

def bin_to_dec(s):
    return int(s, 2)

def any_to_dec(s, base):
    return int(s, base)

print("=== 进制转换工具 ===")
test_nums = [10, 25, 100, 255, 1024]
print("\n十进制 → 二进制/八进制/十六进制:")
for n in test_nums:
    print(f"  {n:5d} → 二进制:{dec_to_bin(n):>10s}  八进制:{dec_to_oct(n):>4s}  十六进制:{dec_to_hex(n):>2s}")

print("\n二进制 → 十进制:")
bin_nums = ["1010", "11001", "11111111"]
for s in bin_nums:
    print(f"  {s} → {bin_to_dec(s)}")

print("\n任意进制 → 十进制:")
print(f"  FF(16进制) → {any_to_dec('FF', 16)}")
print(f"  377(8进制) → {any_to_dec('377', 8)}")
print(f"  1010(2进制) → {any_to_dec('1010', 2)}")
