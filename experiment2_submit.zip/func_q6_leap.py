def isLeap(year):
    return (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0)

leap_years = []
for y in range(1900, 2021):
    if isLeap(y):
        leap_years.append(y)

print("1900~2020年间的闰年：")
count = 0
for y in leap_years:
    print(y, end="  ")
    count += 1
    if count % 5 == 0:
        print()
print(f"\n\n共 {len(leap_years)} 个闰年")
