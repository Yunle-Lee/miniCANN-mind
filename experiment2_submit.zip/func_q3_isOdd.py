def isOdd(n):
    return n % 2 != 0

print("isOdd(5):", isOdd(5))
print("isOdd(8):", isOdd(8))
print("isOdd(-3):", isOdd(-3))
print("isOdd(0):", isOdd(0))

test_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("\n测试列表:", test_numbers)
print("奇数:", [x for x in test_numbers if isOdd(x)])
