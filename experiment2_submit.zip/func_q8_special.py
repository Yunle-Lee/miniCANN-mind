def digit_sum(n):
    return sum(int(d) for d in str(n))

result = []
for n in range(100, 1000):
    s = digit_sum(n * 3)
    if all(digit_sum(n * m) == s for m in range(4, 8)):
        result.append(n)

print(f"共找到 {len(result)} 个满足条件的三位数：\n")
for n in result:
    line = f"{n}: "
    for m in range(3, 8):
        line += f"{n}×{m}={n*m}(各位和={digit_sum(n*m)})  "
    print(line)
