stops = ["人民广场", "中山公园", "徐家汇", "陆家嘴", "南京路", "外滩", "东方明珠"]

print("公交线路站点:", stops)

while True:
    start = input("\n请输入起始站（输入0退出）：")
    if start == "0":
        break
    end = input("请输入终点站：")

    if start not in stops or end not in stops:
        print("站点不存在，请重新输入！")
        continue

    si = stops.index(start)
    ei = stops.index(end)

    if si < ei:
        stops_count = ei - si
        print(f"从 {start} 到 {end}，途经 {stops_count} 站")
        print(f"路线: {' → '.join(stops[si:ei+1])}")
    elif si > ei:
        print(f"需要乘坐反方向线路！从 {start} 到 {end} 需反向乘坐 {si - ei} 站")
        print(f"路线: {' → '.join(stops[ei:si+1][::-1])}")
    else:
        print("起始站和终点站相同")
