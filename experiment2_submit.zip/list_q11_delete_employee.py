employees = [
    ["张三", "男", 28],
    ["李四", "女", 32],
    ["王五", "男", 25],
    ["赵六", "女", 30],
    ["孙七", "男", 35],
]

print("初始员工信息:")
for e in employees:
    print(f"  姓名:{e[0]} 性别:{e[1]} 年龄:{e[2]}")
print()

while True:
    name = input("请输入要删除的员工姓名（输入0退出）：")
    if name == "0":
        break

    found = False
    for e in employees[:]:
        if e[0] == name:
            employees.remove(e)
            found = True
            print(f"已删除员工: {name}")

    if not found:
        print(f"员工 '{name}' 不存在！")

    print("\n当前员工信息:")
    if employees:
        for e in employees:
            print(f"  姓名:{e[0]} 性别:{e[1]} 年龄:{e[2]}")
    else:
        print("  (无员工信息)")
    print()
