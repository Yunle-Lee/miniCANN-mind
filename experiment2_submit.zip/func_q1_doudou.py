def interview():
    for i in range(1, 101):
        if i < 100:
            print(f"记者问第{i}只企鹅：你每天都做什么？")
            print("企鹅回答：吃饭，睡觉，打豆豆！")
        else:
            print(f"记者问第{i}只企鹅：你每天都做什么？")
            print("企鹅回答：吃饭，睡觉。")
            print("记者问：你怎么不打豆豆？")
            print("企鹅回答：我就是豆豆！")

interview()
